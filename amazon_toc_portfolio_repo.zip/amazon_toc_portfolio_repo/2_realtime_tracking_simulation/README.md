# Real-Time Inbound & Outbound Tracking Simulation

**Objective:** Simulate a TOC-style control tower that monitors shipment state changes and triggers escalations for delays.

**Dataset:** `RealTime_Tracking_Simulation.csv` (10 shipments with status and last update).

**Features to Build (suggested):**
- Status board (Picked Up / In-Transit / Delayed / Delivered)
- SLA breach rules (e.g., >24h no scan -> flag)
- Escalation workflow (email/Slack webhook)
- Daily exception summary (auto email)

**Python Pseudocode:**
```python
for row in shipments:
    if row.status == "Delayed":
        escalate_to = owner_map[row.carrier]
        send_alert(escalate_to, row.shipment_id, row.last_updated)
```

**SQL Snippets:**
```sql
-- Exceptions needing escalation (> 24h since last update)
SELECT shipment_id, carrier, current_status, last_updated
FROM tracking
WHERE current_status IN ('In-Transit','Picked Up')
  AND last_updated < NOW() - INTERVAL '24 HOURS';
```