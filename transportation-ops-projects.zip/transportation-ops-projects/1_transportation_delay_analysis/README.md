# Transportation Delay Analysis & Resolution Dashboard

**Objective:** Identify delay trends, quantify business impact, and prioritize escalations to improve on-time delivery (OTD).

**Dataset:** `Transportation_Delay_Analysis.csv` (20 sample shipments with scheduled vs. actual times and reasons).

**Key KPIs:**
- Total Shipments: 20
- On-Time Deliveries: 13
- On-Time Delivery Rate (OTD): 65.0%

**How to Reproduce:**
1. Load the CSV in Power BI or Excel.
2. Create visuals for OTD%, Delivery Delay Distribution, and Delay Reasons.
3. Add a slicer for Carrier / Origin / Destination.
4. Publish to Power BI Service and schedule daily refresh.

**Suggested SQL (for real ops tables):**
```sql
-- OTD by carrier
SELECT
  carrier,
  100.0 * AVG(CASE WHEN actual_delivery <= scheduled_delivery THEN 1 ELSE 0 END) AS otd_percent
FROM shipments
GROUP BY carrier;

-- Top delay reasons (last 30 days)
SELECT delay_reason, COUNT(*) AS cnt
FROM shipments
WHERE actual_delivery > scheduled_delivery
  AND shipment_date >= CURRENT_DATE - INTERVAL '30' DAY
GROUP BY delay_reason
ORDER BY cnt DESC;
```