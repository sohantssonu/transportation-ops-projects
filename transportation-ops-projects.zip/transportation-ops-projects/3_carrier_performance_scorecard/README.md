# Carrier Performance Scorecard & Optimization

**Objective:** Benchmark carrier performance and recommend routing/SLA changes to improve OTD and reduce delay hours.

**Dataset:** `Carrier_Performance_Scorecard.csv`

**KPIs:**
- On-Time Pickup %
- On-Time Delivery %
- Average Delay Hours
- Load Utilization %

**Suggested Actions:**
- Reallocate volume to top carriers on low-risk lanes.
- Joint RCA with carriers below target OTD.
- Negotiate SLA addendums for chronic routes.

**SQL:**
```sql
-- Composite score example
SELECT carrier,
       0.4 * on_time_delivery_pct +
       0.2 * on_time_pickup_pct -
       0.3 * avg_delay_hours +
       0.1 * load_utilization_pct AS composite_score
FROM carrier_daily_kpis
ORDER BY composite_score DESC;
```